import boto3
import awswrangler as wr
from urllib.parse import unquote_plus
# Get the source bucket and object name as passed to the lambda function
def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])

    # we will set the DB and the table name based on the last two elements of thr path prior to the filename. If ker = dms/sakila/film/load01.csv then the following lines will set the db to 'sakila and table_name to film'
    key_list =key.split("/")
    print(f"key_list:{key_list}")
    db_name = key_list[len(key_list)-3]
    table_name = key_list[len(key_list)-2]   
    
    print(f"bucket:{bucket}")
    print(f"key:{key}")
    print(f"db_name:{db_name}")
    print(f"table_name:{table_name}")

    input_path = f"s3://{bucket}/{key}"
    print(f"input_path:{input_path}")
    output_path = f"s3://dataeng-cleaning-zone-k22/{db_name}/{table_name}/"
    print(f"output_path:{output_path}")


    # readin the data from the S3 bucket
    input_df = wr.s3.read_csv([input_path])

    # checking and creating databases

    current_databse = wr.catalog.databases()
    wr.catalog.databases()
    if db_name not in current_databases.values:
        print(f"-database{db_name} does not exist ...creating")
        wr.catalog.create_database(db_name)
    else:
        print(f"-database{db_name} already exists")  

    # using aws sdk for pandas to create a parquet file containing the data we read from the csv file
    result = wr.s3.to_parquet(
        df = input_df,
        path = output_path,
        dataset = True,
        database = db_name,
        table = table_name,
        mode = "append")
    print("RESULT: ")
    print(f"{result}")
    return result        
        
